import { auth } from './firebaseConfig.js';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js';
import { db } from './firebaseConfig.js';
import { collection, addDoc } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js';

// Expresión regular para validar email
const emailPattern = /.+@.+\..+/;

// Expresión regular de contraseña que acepte al menos una letra mayúscula, un número, un símbolo y una longitud mínima de 8 caracteres
const passwordPattern = /^(?=.*[A-Za-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;

// Validación de Login
function validateLogin() {
  const username = document.getElementById("loginUsername").value;
  const password = document.getElementById("loginPassword").value;
  // Limito longitud del campo
  if (username.length < 3) {
    alert("El nombre de usuario debe tener al menos 3 caracteres.");
    return false;
  }
  // Compruebo el formato mínimo de la contraseña
  if (!passwordPattern.test(password)) {
    alert("La contraseña debe tener al menos 8 caracteres, incluir una letra, al menos una mayúscula, un símbolo y un número.");
    return false;
  }
  return true;
}

// Validación de Registro
function validateRegister() {
  const name = document.getElementById("name").value;
  const apellidos = document.getElementById("fullName").value;
  const email = document.getElementById("email").value;
  const edad = document.getElementById("age").value;
  const password = document.getElementById("registerPassword").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  // Limito longitud del campo name
  if (name.length >= 10) {
    alert("El nombre es muy largo.");
    return false;
  }
  // Limito longitud del campo apellidos
  if (apellidos.length >= 40) {
    alert("La longitud del apellido es muy larga.");
    return false;
  }
  // Limito longitud del campo edad
  if (edad > 3 || edad <= 0) {
    alert("La edad no es válida.");
    return false;
  }
  // Compruebo el formato del correo
  if (!emailPattern.test(email)) {
    alert("Por favor, introduce un correo electrónico válido.");
    return false;
  }
  // Compruebo el formato mínimo de la contraseña
  if (!passwordPattern.test(password)) {
    alert("La contraseña debe tener al menos 8 caracteres, incluir una letra, al menos una mayúscula, un símbolo y un número.");
    return false;
  }
  // Confirmo que ha escrito correctamente la contraseña
  if (password !== confirmPassword) {
    alert("Las contraseñas no coinciden.");
    return false;
  }
  return true;
}

// Función para redirigir al usuario
function redirectToPokemons() {
  window.location.href = "/index.html"; // Asegúrate de que esta ruta es correcta
}

// Función para añadir usuario a la base de datos
async function addUserToDatabase(user) {
  try {
    await addDoc(collection(db, "users"), {
      username: document.getElementById("registerUsername").value,
      name: document.getElementById("name").value,
      surname: document.getElementById("fullName").value,
      email: document.getElementById("email").value,
      age: document.getElementById("age").value,
      city: document.getElementById("city").value,
      password: document.getElementById("registerPassword").value
    });
    console.log("Usuario añadido a la base de datos");
  } catch (e) {
    console.error("Error añadiendo el usuario: ", e);
  }
}

// Integración con Firebase
document.getElementById('registerForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if (validateRegister()) {
    const email = document.getElementById('email').value;
    const password = document.getElementById('registerPassword').value;

    createUserWithEmailAndPassword(auth, email, password)
      .then(async (userCredential) => {
        alert("Registro exitoso");
        await addUserToDatabase(userCredential.user);
        redirectToPokemons();
      })
      .catch((error) => {
        alert("Error en el registro: " + error.message);
      });
  }
});

document.getElementById('loginForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if (validateLogin()) {
    const email = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        alert("Inicio de sesión exitoso");
        redirectToPokemons();
      })
      .catch((error) => {
        alert("Error en el inicio de sesión: " + error.message);
      });
  }
});

// Redirigir si ya está autenticado
onAuthStateChanged(auth, (user) => {
  if (user) {
    redirectToPokemons();
  }
});
