// auth/js/firebaseConfig.js
import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js';

const firebaseConfig = {
  apiKey: "AIzaSyAS-o9Zs-sYkXGFA6A2VRDG_nj7fD9JnhM",
  authDomain: "compra-pokemon-b8c41.firebaseapp.com",
  projectId: "compra-pokemon-b8c41",
  storageBucket: "compra-pokemon-b8c41.appspot.com",
  messagingSenderId: "520674867631",
  appId: "1:520674867631:web:f16bdd5ba82d239933d75a"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };
