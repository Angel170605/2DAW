// auth/js/wishList.js
import { db, auth } from './firebaseConfig.js';
import { collection, addDoc, getDocs, query, where } from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js';

export async function addPokemonToWishList(pokemon) {
  const user = auth.currentUser;
  if (user) {
    try {
      await addDoc(collection(db, "wishlists"), {
        userId: user.uid,
        pokemon: pokemon
      });
      console.log("Pokemon añadido a la lista de deseos");
    } catch (e) {
      console.error("Error añadiendo el pokemon: ", e);
    }
  } else {
    alert("Por favor, inicia sesión para añadir a la lista de deseos.");
  }
}

export async function getWishList() {
  const user = auth.currentUser;
  if (user) {
    const q = query(collection(db, "wishlists"), where("userId", "==", user.uid));
    const querySnapshot = await getDocs(q);
    const wishList = [];
    querySnapshot.forEach((doc) => {
      wishList.push(doc.data());
    });
    return wishList;
  } else {
    alert("Por favor, inicia sesión para ver tu lista de deseos.");
  }
}
