// src/views/PokemonView.js
export class PokemonView {
    constructor() {
      this.pokedex = document.getElementById("pokedex");
      this.loadingMessage = document.querySelector(".cargandoDatos");
      this.consoleElements = document.querySelectorAll(".input, .btnMenu");
    }
  
    showLoading() {
      document.querySelector("#button").style.visibility = "hidden";
      this.loadingMessage.style.visibility = "visible";
      this.pokedex.style.visibility = "hidden";
    }
  
    hideLoading() {
      this.loadingMessage.style.visibility = "hidden";
      this.pokedex.style.visibility = "visible";
    }
  
    showConsole() {
      this.consoleElements.forEach((e) => (e.style.visibility = "visible"));
    }
  
    displayPokemons(pokemons) {
      this.pokedex.innerHTML = "";
      pokemons.forEach((pokemon) => {
        let type1 = "";
        let type2 = "";
        if (pokemon.pkm_type.length === 1) {
          type1 = pokemon.pkm_type[0].type.name;
        } else if (pokemon.pkm_type.length === 2) {
          type1 = pokemon.pkm_type[0].type.name;
          type2 = pokemon.pkm_type[1].type.name;
        }
  
        const pokemonCard = document.createElement("div");
        pokemonCard.classList.add("card");
        pokemonCard.id = `pokemon-${pokemon.id}`;
        pokemonCard.innerHTML = `
          <div class="cardTop">
            <div class="poke_name">
              ${pokemon.id}. ${pokemon.name}
            </div>
            <div class="type1" style="${this.getColorByType(type1)};">${type1}</div>
            <div class="type2" style="${this.getColorByType(type2)};">${type2}</div>
          </div>
          <img src="${pokemon.pkm_back}" alt="Back of ${pokemon.name}">
          <img class="front" src="${pokemon.pkm_front}" alt="Front of ${pokemon.name}"><br>
          <div class="poke_stats">
            <div class="stats attack">Attack: ${pokemon.attack}</div>
            <div class="stats height">Height: ${pokemon.height}</div>
            <div class="stats weight">Weight: ${pokemon.weight}</div>
            <div class="stats price">${pokemon.price}€</div>
          </div>
        `;
  
        pokemonCard.addEventListener("click", () => {
          pokemonCard.classList.toggle("selected");
        });
  
        this.pokedex.appendChild(pokemonCard);
      });
    }
  
    getColorByType(type) {
      const colorsByType = {
        fire: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 160, 122), rgb(255, 69, 0))",
        water: "padding: 5px; background-image: linear-gradient(to bottom, rgb(173, 216, 230), rgb(0, 0, 255))",
        electric: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 255, 224), rgb(255, 255, 0))",
        grass: "padding: 5px; background-image: linear-gradient(to bottom, rgb(144, 238, 144), rgb(124, 252, 0))",
        ice: "padding: 5px; background-image: linear-gradient(to bottom, rgb(224, 255, 255), rgb(173, 216, 230))",
        fighting: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 160, 122), rgb(255, 69, 0))",
        poison: "padding: 5px; background-image: linear-gradient(to bottom, rgb(186, 85, 211), rgb(128, 0, 128))",
        ground: "padding: 5px; background-image: linear-gradient(to bottom, rgb(244, 164, 96), rgb(210, 180, 140))",
        flying: "padding: 5px; background-image: linear-gradient(to bottom, rgb(173, 216, 230), rgb(135, 206, 235))",
        psychic: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 182, 193), rgb(255, 20, 147))",
        bug: "padding: 5px; background-image: linear-gradient(to bottom, rgb(240, 255, 240), rgb(173, 255, 47))",
        rock: "padding: 5px; background-image: linear-gradient(to bottom, rgb(211, 211, 211), rgb(169, 169, 169))",
        ghost: "padding: 5px; background-image: linear-gradient(to bottom, rgb(138, 43, 226), rgb(75, 0, 130))",
        dragon: "padding: 5px; background-image: linear-gradient(to bottom, rgb(123, 104, 238), rgb(75, 0, 130))",
        dark: "padding: 5px; background-image: linear-gradient(to bottom, rgb(105, 105, 105), rgb(0, 0, 0))",
        steel: "padding: 5px; background-image: linear-gradient(to bottom, rgb(224, 224, 224), rgb(192, 192, 192))",
        fairy: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 240, 245), rgb(255, 182, 193))",
        normal: "padding: 5px; background-image: linear-gradient(to bottom, rgb(255, 255, 240), rgb(245, 245, 220))",
        default: "background-color: transparent"
      };
      return colorsByType[type] || colorsByType.default;
    }
  }
  