from django.contrib.auth.models import User
from django.shortcuts import redirect, render

from echos.models import Echo

from .forms import EditProfileForm


def user_echos(request, user_id: int):
    owner_user = User.objects.get(id=user_id)
    echos = Echo.objects.filter(user=user_id)
    return render(request, 'user_echos.html', {'owner_user': owner_user, 'echos': echos})


def edit_user_profile(request, user_id):
    user = User.objects.get(id=user_id)
    profile = user.profile
    action = 'Editar perfil de usuario'
    if request.method == 'GET':
        form = EditProfileForm(instance=profile)
    else:
        if (form := EditProfileForm(request.POST, request.FILES, instance=profile)).is_valid():
            profile = form.save()
            profile.save
            return redirect('echos:echos')
    return render(request, 'user_form.html', {'profile': profile, 'form': form, 'action': action})
